"""
Unit tests for the OGhidra project.
""" 