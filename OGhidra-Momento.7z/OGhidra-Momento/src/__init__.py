"""
Ollama-GhidraMCP Bridge
-----------------------
This package provides a bridge between Ollama and GhidraMCP for AI-assisted reverse engineering.
"""

__version__ = "0.1.0" 