#!/usr/bin/env python3
"""
Ollama Client
------------
This module provides a client for interacting with the Ollama API.
"""

import json
import logging
import requests
from typing import Dict, Any, Optional, List

class OllamaClient:
    """Client for interacting with the Ollama API."""
    
    def __init__(self, config):
        """
        Initialize the Ollama client.
        
        Args:
            config: OllamaConfig object with configuration settings
        """
        self.base_url = getattr(config, 'base_url', 'http://localhost:11434')
        self.model_name = getattr(config, 'model', 'llama2')
        self.logger = logging.getLogger("ollama-client")
        
    def generate(self, prompt: str, system: Optional[str] = None, 
                context: Optional[List[Dict[str, str]]] = None) -> str:
        """
        Generate a response from the Ollama model.
        
        Args:
            prompt: The input prompt
            system: Optional system message
            context: Optional conversation context
            
        Returns:
            The generated response text
        """
        url = f"{self.base_url}/api/generate"
        
        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False
        }
        
        if system:
            payload["system"] = system
            
        if context:
            payload["context"] = context
            
        try:
            response = requests.post(url, json=payload)
            response.raise_for_status()
            return response.json()["response"]
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error generating response from Ollama: {str(e)}")
            raise

